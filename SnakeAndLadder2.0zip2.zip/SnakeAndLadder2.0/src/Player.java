public class Player {
    String name;
    int currPos;
    Player(String name){
        this.name = name;
        currPos = 0;
    }
}
