public class NormalCell implements Cell{
    @Override
    public int move() {
        return 0;
    }
}
