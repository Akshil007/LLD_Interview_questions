public interface Cell {
    public int move();
}
